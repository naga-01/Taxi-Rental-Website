function validate(){
  var name = document.getElementById("name").value;
  //var subject = document.getElementById("subject").value;
  var phone = document.getElementById("phone").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message").value;
  var error_message = document.getElementById("error_message");
  var text;
  error_message.style.padding = "10px";
  
  let result = /^[a-zA-Z ]+$/.test(name);
    if(name.length<3||result==false)
    {
      text = "Please Enter Valid name";
      error_message.innerHTML = text;
      return false;
    }

    var phonePattern = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(phonePattern.test(phone)== false){
    text = "Please Enter valid Phone Number";
    error_message.innerHTML = text;
    return false;
  }

  var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  if(emailPattern.test(email) == false){
    text = "Please Enter valid Email";
    error_message.innerHTML = text;
    return false;
  }
  
  if(message.length <= 10){
    text = "Please Enter More Than 10 Characters";
    error_message.innerHTML = text;
    return false;
  }

  alert("Form Submitted Successfully!");
  return true;
}