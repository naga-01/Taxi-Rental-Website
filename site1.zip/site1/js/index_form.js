function validate(){
    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var orgLoca = document.getElementById("orgloc").value;
    var destLoca = document.getElementById("destloc").value;
    var passengers = document.getElementById("passengers").value;
    var ele = document.getElementsByName("cars");
    var error_message = document.getElementById("error_message");
    var text;
    error_message.style.padding = "10px";
     
  
  //Name
      let result = /^[a-zA-Z ]+$/.test(name);
      if(name.length<3||result==false)
      {
        text = "Please Enter Valid name";
        error_message.innerHTML = text;
        return false;
      }
    

  //Phone
     var phonePattern = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
      if(phonePattern.test(phone)== false){

      text = "Please Enter valid Phone Number";
      error_message.innerHTML = text;
      return false;
    }

  //Email
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if(emailPattern.test(email) == false){
      text = "Please Enter valid Email";
      error_message.innerHTML = text;
      return false;
    }


   //Origin Location
    let x = /^[a-zA-Z ]+$/.test(orgLoca);
      if(orgLoca.length<3||x==false)
      {
        text = "Please Enter Valid Origin Location";
        error_message.innerHTML = text;
        return false;
      }


    //Destination Location
      let y = /^[a-zA-Z ]+$/.test(destLoca);
      if(orgLoca==destLoca)
      {
        text = "Origin and Destination Location should not be same";
        error_message.innerHTML = text;
        return false;
      }
      if(destLoca.length<3||y==false)
      {
        text = "Please Enter Valid Destination Location";
        error_message.innerHTML = text;
        return false;
      }

    //Passengers
      if(passengers>25){
      text = "Passengers should be less than 25";
      error_message.innerHTML = text;
      return false;
    }

    //Date
    //var datePattern =/^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;
    //if(datePattern.test(date) == false){
      //text = "Please Enter valid Date";
      //error_message.innerHTML = text;
      //return false;
  //  }

  
    for(i = 0; i < ele.length; i++) { 
      if(ele[i].checked) 
      {
        if(passengers<=4){
          alert( 1 + " " + ele[i].value + " cars booked!!!"); 
        }
        else if(passengers%4==0)
        {
         t = parseInt(passengers/4);
         alert(t + " " + ele[i].value + " cars booked!!!"); 

        }
        else {
          t = parseInt(passengers/4);
          alert((t + 1 ) + " " + ele[i].value + " cars booked!!!"); 
        }
    
    }
  } 
    alert("We will Contact you Shortly with the details!!");
    alert("Thank you for using our services")

    return true;
  }