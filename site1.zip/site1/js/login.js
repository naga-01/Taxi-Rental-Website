
var attempt = 3; // Variable to count number of attempts.

function validate(){
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if( username == "")
    {
        alert("Username can't be blank")
        return 0;
    }
    if (password == "")
    {
        alert("Password can't be blank") 
        return 0;
    }
    else if ( username == "1234" && password == "1234"){       //username = 1234 and password = 1234
                                                  
    alert ("Login successfully");
    window.location = "/home/user/Desktop/site1/index.html"; // Redirecting to Home page of website
    return false;
    }
    else{
    attempt --;// Decrementing by one.
    alert("Incorrect Username or Password!!! You have "+attempt+" attempts left;");
    
    if( attempt == 0){
    document.getElementById("username").disabled = true;
    document.getElementById("password").disabled = true;
    document.getElementById("submit").disabled = true;
    return false;
    }
}
    }
